package com.auriya.ai

import android.app.Application
import com.auriya.ai.data.local.AuriyaDatabase

class AuriyaApp : Application() {
    val database by lazy { AuriyaDatabase.getDatabase(this) }
    override fun onCreate() {
        super.onCreate()
        instance = this
    }
    companion object {
        lateinit var instance: AuriyaApp
            private set
    }
}
