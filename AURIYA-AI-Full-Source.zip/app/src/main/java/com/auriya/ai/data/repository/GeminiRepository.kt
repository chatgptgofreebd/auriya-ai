package com.auriya.ai.data.repository

import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiRepository(private val apiKey: String, private val modelName: String) {
    suspend fun generateResponse(prompt: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "Please configure your Gemini API Key in Settings."
        try {
            val model = GenerativeModel(modelName = modelName, apiKey = apiKey)
            val response = model.generateContent("You are AURIYA AI, a warm female personal assistant. User: $prompt")
            response.text ?: "I couldn't generate a response."
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}
