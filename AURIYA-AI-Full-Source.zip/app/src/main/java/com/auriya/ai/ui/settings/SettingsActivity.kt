package com.auriya.ai.ui.settings

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.auriya.ai.databinding.ActivitySettings
import com.auriya.ai.utils.SecurePreferences

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettings
    private lateinit var prefs: SecurePreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettings.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SecurePreferences(this)
        binding.etApiKey.setText(prefs.apiKey)

        binding.btnSaveSettings.setOnClickListener {
            prefs.apiKey = binding.etApiKey.text.toString().trim()
            Toast.makeText(this, "API Key Saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
