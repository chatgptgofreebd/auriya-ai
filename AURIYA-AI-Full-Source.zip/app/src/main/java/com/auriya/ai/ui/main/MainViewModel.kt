package com.auriya.ai.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auriya.ai.AuriyaApp
import com.auriya.ai.data.model.ChatMessage
import com.auriya.ai.data.repository.GeminiRepository
import com.auriya.ai.utils.SecurePreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = SecurePreferences(application)
    private val db = (application as AuriyaApp).database
    private val geminiRepo = GeminiRepository(prefs.apiKey, prefs.selectedModel)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    init { loadHistory() }

    private fun loadHistory() {
        viewModelScope.launch { _messages.value = db.chatDao().getAllMessages() }
    }

    fun sendMessage(text: String) {
        viewModelScope.launch {
            db.chatDao().insertMessage(ChatMessage(sender = "user", message = text))
            loadHistory()
            val reply = geminiRepo.generateResponse(text)
            db.chatDao().insertMessage(ChatMessage(sender = "auriya", message = reply))
            loadHistory()
        }
    }
}
