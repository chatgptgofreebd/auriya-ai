package com.auriya.ai.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.auriya.ai.databinding.ActivityMain
import com.auriya.ai.ui.settings.SettingsActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMain
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSend.setOnClickListener {
            val query = binding.etInput.text.toString()
            if (query.isNotBlank()) {
                viewModel.sendMessage(query)
                binding.etInput.text.clear()
            }
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        lifecycleScope.launch {
            viewModel.messages.collect { messages ->
                val sb = StringBuilder()
                for (msg in messages) {
                    sb.append("${if (msg.sender == "user") "You" else "AURIYA"}: ${msg.message}\n\n")
                }
                binding.tvChatLog.text = sb.toString()
            }
        }
    }
}
