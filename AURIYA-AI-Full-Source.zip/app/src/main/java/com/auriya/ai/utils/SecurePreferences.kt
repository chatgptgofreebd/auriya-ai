package com.auriya.ai.utils

import android.content.Context
import android.content.SharedPreferences

class SecurePreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("auriya_secure_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value).apply()

    var selectedModel: String
        get() = prefs.getString("selected_model", "gemini-1.5-flash") ?: "gemini-1.5-flash"
        set(value) = prefs.edit().putString("selected_model", value).apply()
}
